/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.analyse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class AnalyseMessageModel {
    private String message;
    
    
    public AnalyseMessageModel(String message){
        this.message = message;
    }
    
    //Determine the number of words 
    public int numberOfWords(String message){
        if(message == null || message.isEmpty()){
            return 0;
        }
        
        //split the message by whitespaces 
        String[] word = message.trim().split("\\s+");
        int numWords = word.length;
        return numWords;
    }
    
    //Count the occurences of President and Cyril
    public int keywordCount(){
        if(message == null || message.isEmpty()){
            return 0;
        }
        
        String[] numWords = message.trim().split("\\s+");
        int count = 0;
        
        for(String word: numWords){
            if(word.equalsIgnoreCase("President") || word.equalsIgnoreCase("Cyril")){
                count++;
            }
        }
        return count;
    }
        
     //Calculate the frequency of keyword occurrences
    public double keywordFrequency(){
        int totalWords = numberOfWords(message);
        int keywordOccurrences = keywordCount();
        
        if(totalWords == 0){
            return 0;
        }
        
        return (keywordOccurrences / (double)totalWords)* 100;
    }
    
    //Classify essages as harmful 
    public String classifyMessage(){
        double frequency = keywordFrequency();
        String result = null;
        
        if(frequency > 30){
            result = "harmful";
        }else{
            result = "harmless";
        }
       return result;
    }
    
    /*public void updateStatus(HttpServletRequest request){
    
        HttpSession session = request.getSession();
        
        
        if(message != null){
            
        Integer totNumMsg = (Integer) session.getAttribute("totNumMsg");
        
        totNumMsg++;
        
        session.setAttribute("totNumMsg", totNumMsg);
        
        }
       
        
        
        
    
    
    }*/
    
}
