/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model;

/**
 *
 * @author HP
 */
public class ArithmeticOperationsManager implements ArithmeticOperationsInterface {
    
    @Override
    public int add(int num1, int num2) throws NumbersException{
    if(isValid(num1,num2)){
            
        return (num1 + num2);
    }else{
        throw new NumbersException("The numbers must be positive [" + num1 + "," + num2 + "]");
    }
}
    @Override
    public int subtract(int num1, int num2) throws NumbersException{
        if(isValid(num1,num2)){
            return (num1 - num2);
        }else{
            throw new NumbersException("The numbers must be positive [" + num1 + "," + num2 + "]");
        }
    }
    
    private boolean isValid(int num1, int num2){
        boolean valid = false;
        
        if(num1 > 0 && num2 > 0){
            valid = true;
        }
        return valid;
    }
}
