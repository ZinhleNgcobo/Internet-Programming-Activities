/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model;

/**
 *
 * @author HP
 */
public interface ArithmeticOperationsInterface {
    
    public int add(int num1, int num2) throws NumbersException;
    public int subtract(int num1, int num2) throws NumbersException;
    
}
