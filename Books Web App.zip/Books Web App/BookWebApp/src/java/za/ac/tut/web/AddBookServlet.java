/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.bl.BookFacadeLocal;
import za.ac.tut.entities.Author;
import za.ac.tut.entities.Book;

/**
 *
 * @author HP
 */
public class AddBookServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddBookServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AddBookServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    @EJB
    private BookFacadeLocal bfl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long isbn = Long.parseLong(request.getParameter("isbn"));
        String title = request.getParameter("title");
        Double price = Double.parseDouble(request.getParameter("price"));
        String authorName = request.getParameter("name");
        String authorSurname = request.getParameter("surname");
        
        String pubDate = request.getParameter("pubDate");
        SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd");
        try{

            Date date = format.parse(pubDate);
            Book book = createBook(isbn,title,price,date,authorName,authorSurname);
            bfl.create(book);
        }catch(ParseException e){
            e.printStackTrace();
        }
        
        RequestDispatcher disp = request.getRequestDispatcher("add_book_outcome.jsp");
        disp.forward(request, response);
        
    }
    private Book createBook(Long isbn,String title,Double price, Date date, String authorName,String authorSurname){
        Book b = new Book();
        Author author = new Author();
        author.setName(title);
        author.setSurname(authorName);
        b.setId(isbn);
        b.setTitle(title);
        b.setPrice(price);
        b.setPublicationDate(date);
        b.setAuthor(author);
        b.setCreationDate(new Date());
        return b;
    }
   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
