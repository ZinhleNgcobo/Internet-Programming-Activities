/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model;

/**
 *
 * @author HP
 */
public class PersonalizedGreetingsGenerator {
    private String name;
    private char gender;
    
    public PersonalizedGreetingsGenerator(String name,char gender){
        this.name = name;
        this.gender = gender;
    }
    
    public String generateGreeting(){
        String title, greeting;
        
        title = determineTitle();
        greeting = "Hi " + title + " " + name + ". Welcome to the wolrd of web development.";
        return greeting;
    }
    
    private String determineTitle(){
        String title = "Mr";
        
        if(gender == 'F' || gender == 'f'){
            title = "Ms";
        }
        return title;
    }
}
