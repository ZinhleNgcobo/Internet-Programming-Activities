/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.bl.Student1FacadeLocal;
import za.ac.tut.entities.Student1;

/**
 *
 * @author HP
 */
public class GetTestStatisticsServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet GetTestStatisticsServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet GetTestStatisticsServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    @EJB
    private Student1FacadeLocal sfl;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       List<Student1> list = sfl.findAll();
       Integer cnt = sfl.count();
       
       Double lowestMark = sfl.getLowestMark();
       Double highestMark = sfl.getHighestMark();
       Double avgMark = sfl.getAvgMark();
       
       Long cntPassed = sfl.cntAllPassedStudents();
       Long cntFailed = sfl.cntAllFailedStudents();
       
       Long numMales = sfl.cntAllMaleStudents();
       Long numFemales = sfl.cntAllFemaleStudents();
       
       Long numMalesPassed = sfl.cntAllPassedMaleStudents();
       Long numFemalesPassed = sfl.cntAllPassedFemaleStudents();
       
       Long numMalesFailed = sfl.cntAllFailedMaleStudents();
       Long numFemalesFailed = sfl.cntAllFailedFemaleStudents();
       
       //set Attribues to display the statistics
       request.setAttribute("list", list);
       request.setAttribute("cnt", cnt);
       request.setAttribute("lowestMark", lowestMark);
       request.setAttribute("highestMark", highestMark);
       request.setAttribute("avgMark", avgMark);
       request.setAttribute("cntPassed", cntPassed);
       request.setAttribute("cntFailed", cntFailed);
       request.setAttribute("numMales", numMales);
       request.setAttribute("numFemales",numFemales);
       request.setAttribute("numMalesPassed", numMalesPassed);
       request.setAttribute("numFemalesPassed", numFemalesPassed);
       request.setAttribute("numMalesFailed", numMalesFailed);
       request.setAttribute("numFemalesFailed", numFemalesFailed);
       
       RequestDispatcher disp = request.getRequestDispatcher("get_stats_outcome.jsp");
       disp.forward(request, response);
       
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
