/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.entities.Student1;

/**
 *
 * @author HP
 */
@Stateless
public class Student1Facade extends AbstractFacade<Student1> implements Student1FacadeLocal {

    @PersistenceContext(unitName = "TestPerformanceEJBModuleV1PU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public Student1Facade() {
        super(Student1.class);
    }
    
    @Override
    public Long cntAllFemaleStudents(){
        Query query = em.createQuery("SELECT count(s) FROM Student1 s WHERE s.gender = 'F'");
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }
    
    @Override
    public Long cntAllMaleStudents(){
        Query query = em.createQuery("SELECT count(s) FROM Student1 s WHERE s.gender = 'M'");
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }
    
    @Override
    public Long cntAllPassedStudents(){
        Query query = em.createQuery("SELECT count(s) FROM Student1 s WHERE s.percMarkObtained > 50.0");
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }
    
    @Override
    public Long cntAllFailedStudents(){
        Query query = em.createQuery("SELECT count(s) FROM Student1 s WHERE s.percMarkObtained < 50.0");
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }
    
    @Override
    public Long cntAllPassedFemaleStudents(){
        Query query = em.createQuery("SELECT count(s) FROM Student1 s WHERE s.percMarkObtained > 50.0 AND s.gender = 'F'");
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }
    
    @Override
    public Long cntAllPassedMaleStudents(){
        Query query = em.createQuery("SELECT count(s) FROM Student1 s WHERE s.percMarkObtained > 50.0 AND s.gender = 'M'");
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }
    
    @Override
    public Long cntAllFailedFemaleStudents(){
       Query query = em.createQuery("SELECT count(s) FROM Student1 s WHERE s.percMarkObtained < 50.0 AND s.gender = 'F'");
       Long cnt = (Long)query.getSingleResult();
       return cnt;
    }
    
    @Override
    public Long cntAllFailedMaleStudents(){
        Query query = em.createQuery("SELECT count(s) FROM Student1 s WHERE s.percMarkObtained <50.0 AND s.gender = 'M'");
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }
    
    @Override
    public List<Student1> findStudentWithinAgeRange(Integer minAge,Integer maxAge){
        Query query = em.createQuery("SELECT s FROM Student1 s WHERE s.age >= :minTargetAge AND s.age <= :maxTargetAge");
        query.setParameter("minTargetAge", minAge);
        query.setParameter("maxTargetAge", maxAge);
        List<Student1> students = query.getResultList();
        return students;
    }
    
    @Override
    public Student1 finds(String name, String surname) {
    Query query = em.createQuery("SELECT s FROM Student1 s WHERE s.firstName = :fname AND s.lastName = :lname");
    query.setParameter("fname", name);
    query.setParameter("lname", surname);
    Student1 student = (Student1)query.getSingleResult();
    return student;
    
}
    @Override
    public Double getHighestMark(){
       Query query = em.createQuery("SELECT MAX(s.percMarkObtained) FROM Student1 s");
       Double maxMark = (Double)query.getSingleResult();
       return maxMark;
    }
    
    @Override
    public Double getLowestMark(){
       Query query = em.createQuery("SELECT MIN(s.percMarkObtained) FROM Student1 s"); 
       Double minMark = (Double)query.getSingleResult();
       return minMark;
    }
    
    @Override
    public Double getAvgMark(){
        Query query = em.createQuery("SELECT AVG(s.percMarkObtained) FROM Student1 s");
        Double avgMark =(Double)query.getSingleResult();
        return avgMark;
    }
}
