/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.entities.Student1;

/**
 *
 * @author HP
 */
@Local
public interface Student1FacadeLocal {

    void create(Student1 student1);
    void edit(Student1 student1);
    void remove(Student1 student1);

    Student1 find(Object id);
    public Student1 finds(String name, String surname);
    

    List<Student1> findAll();
    List<Student1> findRange(int[] range);
    List<Student1> findStudentWithinAgeRange(Integer minAge, Integer maxAge);
    
    Long cntAllMaleStudents();
    Long cntAllFemaleStudents();
    Long cntAllPassedMaleStudents();
    Long cntAllPassedFemaleStudents();
    Long cntAllFailedMaleStudents();
    Long cntAllFailedFemaleStudents();
    Long cntAllPassedStudents();
    Long cntAllFailedStudents();
    
    Double getHighestMark();
    Double getLowestMark();
    Double getAvgMark();

    int count();
    
}
