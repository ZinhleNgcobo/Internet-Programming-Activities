/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testing.method;

/**
 *
 * @author HP
 */
public class CheckPalindromeValue {
   
    private int value;
   
    public CheckPalindromeValue(int value){
        this.value = value;
    }
    
    public boolean isPalindrome(){
        int initialValue = value;
        int reversedValue =0;
        int temp = value;
        
        while(temp > 0){
            int lastDigit = temp % 10;
            reversedValue = reversedValue * 10 + lastDigit;
            temp /= 10;
        }
        //compare
        return initialValue == reversedValue;
    }
    
    
    
    
    
}
